export function saludarConsola(){
    console.log("hola desde modulo 1 por consola");
}

