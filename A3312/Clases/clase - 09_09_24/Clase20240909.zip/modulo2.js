import { saludarConsola } from "./modulo1.js";

saludarConsola();


